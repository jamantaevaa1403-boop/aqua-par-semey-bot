
import os, json, threading, asyncio
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from flask import Flask, jsonify
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

load_dotenv()
DATA_DIR = Path("data"); DATA_DIR.mkdir(parents=True, exist_ok=True)
STATE_PATH = DATA_DIR / "state.json"

def load_state():
    if STATE_PATH.exists():
        try:
            return json.loads(STATE_PATH.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {"admin_chat_id": os.getenv("ADMIN_CHAT_ID","").strip(), "users": {}}

def save_state(st): STATE_PATH.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding='utf-8')

state = load_state()

TOKEN = os.getenv("TELEGRAM_TOKEN")
BUSINESS = os.getenv("BUSINESS_NAME", "Аква Пар Семей")
ADMIN_NAME = os.getenv("ADMIN_DISPLAY_NAME", "Администратор")
ADDRESS = os.getenv("ADDRESS", "г. Семей, ул. Автодорожная 43")
PRICE = os.getenv("PRICE_INFO", "7000 ₸ за 2 часа")
MAX_GUESTS = os.getenv("MAX_GUESTS", "до 6 человек")
POOL = os.getenv("POOL_INFO", "Тёплый бассейн с подогревом, глубина 1.5 м, 1.6×1.6 м")
KARAOKE = os.getenv("KARAOKE_INFO", "Профессиональная караоке-система")
WORKING_HOURS = os.getenv("WORKING_HOURS", "ежедневно 12:00–00:00")
ADMIN_PHONE = os.getenv("ADMIN_PHONE", "8 776 700 40 45")

MENU_KB = ReplyKeyboardMarkup(
    [[KeyboardButton("📅 Забронировать"), KeyboardButton("💰 Цена")],
     [KeyboardButton("📍 Адрес"), KeyboardButton("ℹ️ О нас")]], resize_keyboard=True
)

awaiting_details = set()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_chat.id)
    user = state["users"].get(uid) or {"seen": False, "name": (update.effective_user.first_name or "")}
    returning = user.get("seen", False)
    user["seen"] = True
    state["users"][uid] = user; save_state(state)
    greet = f"👋 {'Снова рады вас видеть' if returning else 'Добро пожаловать'} в «{BUSINESS}»!"
    await update.message.reply_text(greet, reply_markup=MENU_KB)

async def iamadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state["admin_chat_id"] = str(chat_id); save_state(state)
    await update.message.reply_text("✅ Вы назначены администратором. Буду присылать вам заявки здесь.")
    await context.bot.send_message(chat_id=chat_id, text=f"💬 Бот «{BUSINESS}» успешно запущен и готов к работе!")

async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip().lower()
    chat_id = update.effective_chat.id; uid = str(chat_id)
    if text in ("📅 забронировать","забронировать"):
        awaiting_details.add(uid)
        await update.message.reply_text(
            "🕐 Укажите желаемую дату и время, например: «12 ноября в 18:00, 2 часа».\\n"
            f"После заявки администратор {ADMIN_NAME} свяжется с вами для подтверждения ✅",
            reply_markup=MENU_KB
        ); return
    if text in ("💰 цена","цена","сколько"):
        await update.message.reply_text(f"💰 Стоимость посещения: {PRICE}. Минимальная длительность 2 часа.", reply_markup=MENU_KB); return
    if text in ("📍 адрес","адрес","где"):
        await update.message.reply_text(f"📍 Адрес: {ADDRESS}\\n🕒 Режим работы: {WORKING_HOURS}", reply_markup=MENU_KB); return
    if text in ("ℹ️ о нас","о нас","инфо","информация"):
        await update.message.reply_text(
            f"ℹ️ «{BUSINESS}»\\n👥 Вместимость: {MAX_GUESTS}\\n🏊 {POOL}\\n🎤 {KARAOKE}\\n🕒 Режим: {WORKING_HOURS}\\n📞 Телефон администратора: {ADMIN_PHONE}",
            reply_markup=MENU_KB
        ); return
    if uid in awaiting_details or any(k in text for k in ["сегодня","завтра","послезавтра","нояб","дек","янв","фев","мар","апр","мая","июн","июл","авг","сен","окт"]):
        awaiting_details.discard(uid)
        admin_chat_id = state.get("admin_chat_id")
        if admin_chat_id:
            msg = ("📩 Новая предзаявка от клиента:\\n"
                   f"Имя: {update.effective_user.full_name}\\n"
                   f"Username: @{update.effective_user.username or '—'}\\n"
                   f"Чат ID: {uid}\\n"
                   f"Сообщение: {update.message.text}\\n"
                   f"— От бота {BUSINESS} 💦")
            await context.bot.send_message(chat_id=int(admin_chat_id), text=msg)
        await update.message.reply_text(
            f"✅ Спасибо! Я передал вашу заявку администратору {ADMIN_NAME}.\\n"
            f"Для завершения бронирования, пожалуйста, позвоните: 📞 {ADMIN_PHONE}",
            reply_markup=MENU_KB
        ); return
    await update.message.reply_text("Выберите действие ниже 👇", reply_markup=MENU_KB)

flask_app = Flask(__name__)
@flask_app.get("/")
def health(): return jsonify(ok=True, service="Aqua Par Semey Telegram Bot (Render)", started=datetime.utcnow().isoformat())

def start_bot():
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("iamadmin", iamadmin))
    application.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), text_router))

    async def runner():
        await application.initialize()
        await application.start()
        await application.updater.start_polling(allowed_updates=Update.ALL_TYPES)
        await application.updater.idle()

    asyncio.run(runner())

threading.Thread(target=start_bot, daemon=True).start()

if __name__ == "__main__":
    port = int(os.environ.get("PORT","10000"))
    flask_app.run(host="0.0.0.0", port=port)
