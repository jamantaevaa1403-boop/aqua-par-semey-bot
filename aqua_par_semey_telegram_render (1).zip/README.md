
# Telegram Bot — Аква Пар Семей (Render 24/7)

## Быстрый старт
1) Зайдите на https://render.com → New → Web Service → Upload a .zip/tar → загрузите этот архив.
2) Название: aqua-par-semey-telegram • Environment: Python 3 • Instance type: Free → Create Web Service.
3) После запуска найдите своего бота в Telegram и отправьте ему: /start, затем /iamadmin (зарегистрируете свой чат как админский).

Теперь все предзаявки будут приходить вам в Telegram.
